var plasma = getApiVersion(1);

var layout = {
    "desktops": [
        {
            "applets": [
            ],
            "config": {
                "/": {
                    "ItemGeometries-1536x864": "",
                    "ItemGeometriesHorizontal": "",
                    "formfactor": "0",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                },
                "/ConfigDialog": {
                    "DialogHeight": "630",
                    "DialogWidth": "810"
                },
                "/Wallpaper/org.kde.image/General": {
                    "Image": "file:///home/ruvix/Изображения/27-Golden-Gate-Dark.png",
                    "SlidePaths": "/home/ruvix/.local/share/wallpapers/,/usr/share/wallpapers/"
                }
            },
            "wallpaperPlugin": "org.kde.image"
        }
    ],
    "panels": [
        {
            "alignment": "center",
            "applets": [
                {
                    "config": {
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "810"
                        },
                        "/General": {
                            "customButtonImage": "org.cachyos.hello",
                            "floating": "true",
                            "useCustomButtonImage": "true"
                        }
                    },
                    "plugin": "TahoeLauncher"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.appmenu"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.panelspacer"
                },
                {
                    "config": {
                        "/ConfigDialog": {
                            "DialogHeight": "630",
                            "DialogWidth": "810"
                        }
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.systemtray"
                },
                {
                    "config": {
                    },
                    "plugin": "com.github.idityage.spacerdivider"
                },
                {
                    "config": {
                        "/": {
                            "popupHeight": "419",
                            "popupWidth": "420"
                        }
                    },
                    "plugin": "KdeControlStation"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.marginsseparator"
                },
                {
                    "config": {
                        "/": {
                            "popupHeight": "451",
                            "popupWidth": "560"
                        }
                    },
                    "plugin": "org.kde.plasma.digitalclock"
                },
                {
                    "config": {
                    },
                    "plugin": "org.kde.plasma.showdesktop"
                }
            ],
            "config": {
                "/": {
                    "formfactor": "2",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                }
            },
            "height": 1.6666666666666667,
            "hiding": "normal",
            "lengthMode": "fill",
            "location": "top",
            "maximumLength": 85.33333333333333,
            "minimumLength": 85.33333333333333,
            "offset": 0,
            "opacity": "adaptive"
        },
        {
            "alignment": "center",
            "applets": [
                {
                    "config": {
                        "/General": {
                            "launchers": "preferred://filemanager,applications:systemsettings.desktop,applications:org.kde.konsole.desktop,applications:arch-update.desktop,applications:nvidia-settings.desktop,applications:org.bleachbit.BleachBit.desktop,preferred://browser,applications:portprotonqt-1.5.0-anylinux-x86_64.desktop,applications:btrfs-assistant.desktop,applications:org.qbittorrent.qBittorrent.desktop,applications:org.vinegarhq.Sober.desktop,applications:xmcl-0.72.0-x86_64.desktop,applications:_______.desktop"
                        }
                    },
                    "plugin": "org.kde.plasma.icontasks"
                }
            ],
            "config": {
                "/": {
                    "formfactor": "2",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                }
            },
            "height": 3.5555555555555554,
            "hiding": "windowsgobelow",
            "lengthMode": "fit",
            "location": "bottom",
            "maximumLength": 85.33333333333333,
            "minimumLength": 85.33333333333333,
            "offset": 0,
            "opacity": "translucent"
        }
    ],
    "serializationFormatVersion": "1"
}
;

plasma.loadSerializedLayout(layout);
